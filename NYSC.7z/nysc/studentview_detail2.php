<?php include "header2.php"?>
<?php include "conn.php"?>
<?php 
$sql=$conn->query("select * from schools where usernames='".$_SESSION['USER']."'") or die($conn->error);
$ro=$sql->fetch_assoc();?>
<?php 
if(isset($_GET['del'])){$id=$_GET['del'];
 
$sql=$conn->query("DELETE FROM `students` where `id`='$id'") or die($conn->error);

echo '<script>alert("Data Deleted..");</script>';

echo '<script>window.location.href="mobilizationlist.php";</script>';

}
?>


<?php $sql=$conn->query("select * from students where id='".$_GET['id']."'")  or die($conn->error);
                      $row=$sql->fetch_assoc();?>



<div id="overviews" class="section lb">
        <div class="container">    
            <div class="row align-items-center">
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    <div class="message-box">
                        <h2>WELCOME TO THE NYSC POSTING SYSTEM</h2>
                        <h4>ABOUT THE SCHEME</h4>
                        <p>  
                    <ul>
                        <li>CALLUP :- <?php echo $row['callup'];?></li>
                        <li>SURNAME :- <?php echo $row['surname'];?> </li>
                        <li>OTHER NAME :- <?php echo $row['othername'];?></li>
                        <li>SEX :- <?php echo $row['sex'];?></li>
                        <li>DOB :- <?php echo $row['dob'];?></li>
                        <li>STATE :- <?php echo $row['state'];?></i>
                        <li>SCHOOL NAME :- <?php echo $row['schoolname'];?></li>
                        <li>COURSE :- <?php echo $row['course'];?></li>
                        <li>POSTING :- <?php echo $row['posting'];?></li>
                    </u>
.</p>


                    </div><!-- end messagebox -->
                </div><!-- end col -->






				
				<div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    <div class="post-media wow fadeIn">
                        <img src="img/nysc.jpg" alt="" class="img-fluid img-rounded">
                    </div><!-- end media -->
                </div><!-- end col -->

                <div class="d-flex align-items-center">
                            <a type="button" class="btn btn-light btn-radius btn-brd grd1" onclick="window.print();return false;" href="">
                            Print                        
                      </a>
                          </div>
			</div>
			
        </div><!-- end container -->
    </div><!-- end section -->

    <?php include ("footer.php")?>