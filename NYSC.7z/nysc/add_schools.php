<?php include "header1.php"?>
<?php include("conn.php")?>


<?php 
if(isset($_POST['name'])){

  $name=$_POST['name'];
  $address=$_POST['address'];
  $category=$_POST['category'];
  $assigncode=$_POST['assigncode'];
  $usernames=$_POST['usernames'];
  $password=$_POST['password'];
  

$sql=$conn->query("INSERT INTO `schools`( `name`, `address`, `category`,  `assigncode`, `usernames`, `password`) VALUES ('$name', '$address','$category', '$assigncode','$usernames', '$password')") or die($conn->error);

  }
?>
	
	
    <div id="overviews" class="section lb">
        <div class="container">
            <div class="section-title row text-center">
                <div class="col-md-10 offset-md-2">
                    <h3>Create School Account</h3>
                    <form role="form" class="form-horizontal"  method="POST">
							<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" name="name" placeholder="School Name" type="text">
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" name="address" id="address" placeholder="Address" type="text">
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" name="category" id="category" placeholder="category" type="text">
								</div>
                                </div>
                                <div class="form-group">
                                    
								<div class="col-sm-12">
									<input class="form-control" name="assigncode" id="assigncode" placeholder="AssignCode" type="text">
								</div>
                                </div>
                                <div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" name="usernames" id="username" placeholder="Usernames" type="text">
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" name="password" id="password" placeholder="Password" type="password">
								</div>
							</div>
							<div class="row">							
								<div class="col-sm-10">
									<button type="submit" class="btn btn-light btn-radius btn-brd grd1">
										Proceed
									</button>
									<button type="rest" class="btn btn-light btn-radius btn-brd grd1">
										Cancel</button>
								</div>
							</div>
						</form>

                </div>
            </div><!-- end title -->
        
				
				
				
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end section -->













   

    <?php include "footer.php"?>