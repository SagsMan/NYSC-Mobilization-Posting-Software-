<?php include "header1.php"?>
<?php include("conn.php")?>
<?php 
if(isset($_GET['del'])){

  $id=$_GET['del'];
 
$sql=$conn->query("DELETE FROM `students` where `id`='$id'") or die($coon->error);

echo '<script>alert("Data Deleted..");</script>';

echo '<script>window.location.href="studentview.php";</script>';

}
?>
	
	
    <div id="overviews" class="section lb">
        <div class="container">
            <div class="section-title row text-center">
                <div class="col-md-10 offset-md-2">
                    <h3>Student Record Database</h3>
                    <table class="table table-striped project-orders-table">
                    <thead>
                      <tr>
                        <th class="ml-5">SN</th>
                        <th>CALLUP</th>
                        <th>SURNAME</th>
                        <th>OTHERNAME</th>
                        <th>SEX</th>
                        <th>DOB</th>
                        <th>STATE</th>
                        <th>SCHOOL NAME</th>
                        <th>COURSE</th>
                        <th>POSTING</th>
                       <!-- <th>Actions</th>-->
                        
                       
               
                       
                      </tr>
                    </thead>
                    <tbody>
                    <?php $i=1;
                      $sql=$conn->query("select * from students")  or die($conn->error);
                      while($row=$sql->fetch_assoc()){?>
                      <tr>
                        <td><?php echo $i++;?></td>
                        <td><?php echo $row['callup'];?> </td>
                        <td><?php echo $row['surname'];?></td>
                        <td><?php echo $row['othername'];?></td>
                        <td><?php echo $row['sex'];?></td>
                        <td><?php echo $row['dob'];?></td>
                        <td><?php echo $row['state'];?></td>
                        <td><?php echo $row['schoolname'];?></td>
                        <td><?php echo $row['course'];?></td>
                        <td><?php echo $row['posting'];?></td>
                      
                        
                      
                          <div class="d-flex align-items-center">
                         <!--  <td> <a type="button" class="btn btn-danger btn-sm btn-icon-text mr-3" href="studentview.php?del=<?php echo $row['id'];?>">
                              Deleted
                              <i class="typcn typcn-edit btn-icon-append"></i>                          
                      </a>
                      </td>-->
                           
                          </div>
                      </tr>
                        
                       
                          </div>
                        </td>
                      </tr>
                      <?php }?>
                                 
                                            
                    </tbody>
                  </table>

                </div>
            </div><!-- end title -->
        
				
				
				
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end section -->













   

    <?php include "footer.php"?>