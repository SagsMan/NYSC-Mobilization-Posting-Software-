<?php include "header1.php"?>
<?php
include ('conn.php'); 
if(isset($_POST['callup'])){
    $callup =$_POST['callup'];
    $surname =$_POST['surname'];
    $othername =$_POST['othername'];
    $sex =$_POST['sex'];
    $dob =$_POST['dob'];
    $state =$_POST['state'];
    $schoolname =$_POST['schoolname'];
    $course =$_POST['course'];
    $posting =$_POST['posting'];
   
    $sql= $conn->query("update `students` set `callup`='".$callup."', `surname`='".$surname."', `othername`='".$othername."', `sex`='".$sex."', `dob`='".$dob."', `state`='".$state."', `schoolname`='".$schoolname."', `course`='".$course."', `posting`='".$posting."' where id ='".$_GET['id']."'")or die($conn->error);
   header("location:mobilizationlist.php");
   echo '<script>window.location.href="mobilizationlist.php";</script>';

}     
?>
<div id="overviews" class="section lb">
        <div class="container">
            <div class="section-title row text-center">
                <div class="col-md-10 offset-md-2">
                    <h3>Add Student</h3>
                    <?php $sql=$conn->query("select * from students where id='".$_GET['id']."'")or die($conn->error);
    $row=$sql->fetch_assoc();
    ?>
                    <form action="" method="POST">
							<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" name="callup" id="callup" placeholder="Callup" type="text" required value="<?php echo $row['callup'];?>">
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" name="surname" id="surname" placeholder="Surname" type="text"  required value="<?php echo $row['surname'];?>">
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" name="othername" id="othername" placeholder="Othername" type="text"  required value="<?php echo $row['othername'];?>">
								</div>
                                </div>
                                <div class="form-group">
                                    
								<div class="col-sm-12">
									<input class="form-control" name="sex" id="sex" placeholder="Sex" type="text"  required value="<?php echo $row['sex'];?>">
								</div>
                                </div>
								<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" name="dob" id="dob" placeholder="Dob" type="date"  required value="<?php echo $row['dob'];?>">
								</div>
							</div>
                                <div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" name="state" id="state" placeholder="State" type="text"  required value="<?php echo $row['state'];?>">
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" name="schoolname" id="schoolname" placeholder="School Name" type="text"  required value="<?php echo $row['schoolname'];?>">
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" name="course" id="course" placeholder="Course" type="text"  required value="<?php echo $row['course'];?>">
								</div>
							</div>
                           <div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" name="posting" id="posting" placeholder="Posting" type="text" 
                                    required value="<?php echo $row['posting'];?>">
								</div>
							</div>
							<div class="row">							
								<div class="col-sm-10">
									<button type="submit" class="btn btn-light btn-radius btn-brd grd1">
										Save &amp; Continue
									</button>
									<button type="reset" class="btn btn-light btn-radius btn-brd grd1">
										Cancel</button>
								</div>
							</div>
						</form>

                </div>
            </div><!-- end title -->
        
				
				
				
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end section -->

    <?php include ("footer.php")?>