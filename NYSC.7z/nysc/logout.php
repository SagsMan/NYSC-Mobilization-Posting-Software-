<?php 
session_start();
$_SESSION['USER']='';
$_SESSION['USER']=NULL;
unset($_SESSION['USER']);
echo'<script>window.location.href="index.php";</script>';

?>