<?php include "header2.php"?>
<?php include "conn.php"?>

    <div id="overviews" class="section lb">
        <div class="container">
            <div class="section-title row text-center">
                <div class="col-md-10 offset-md-1">
                    <h3>NATIONAL YOUTH SERVICE CORPS MOBILIZATION LIST</h3>
                    
          
                    <table class="table table-striped project-orders-table">
                    <thead>
                      <tr>
                        <th class="ml-5">SN</th>
                        <th>CALLUP</th>
                        <th>SURNAME</th>
                        <th>OTHERNAME(S)</th>
                        <th>SEX</th>
                        <th>DOB</th>
                        <th>STATE</th>
                        <th>COURSE</th>
                        <th>POSTING</th>
                      
               
                       <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php $i=1;
                      $sql=$conn->query("select * from students")  or die($conn->error);
                      while($row=$sql->fetch_assoc()){?>
                      <tr>
                        <td><?php echo $i++;?></td>
                        <td><?php echo $row['callup'];?> </td>
                        <td><?php echo $row['surname'];?></td>
                        <td><?php echo $row['othername'];?></td>
                        <td><?php echo $row['sex'];?></td>
                        <td><?php echo $row['dob'];?></td>
                        <td><?php echo $row['state'];?></td>
                        <td><?php echo $row['course'];?></td>

                        <td><?php echo $row['posting'];?></td>
               
                        <td>   <!-- end title -->
                          <div class="d-flex align-items-center">
                         
                              <a type="button" class="btn btn-success btn-sm btn-icon-text mr-3" href="result_view.php?edit=16">
                              View
                              <i class="typcn typcn-edit btn-icon-append"></i>                          
                      </a>                     
                      </a>
                              <i class="typcn typcn-edit btn-icon-append"></i>                          
                      </a>
                           <a type="button" class="btn btn-success btn-sm btn-icon-text mr-3" href="result_view.php?edit=16">
                              Edit
                              <i class="typcn typcn-edit btn-icon-append"></i>                          
                      </a>
                            <a type="button" class="btn btn-danger btn-sm btn-icon-text" href="result_view.php?del=16">
                              Delete
                              <i class="typcn typcn-delete-outline btn-icon-append"></i>                          
                      </a>
                          </div>
                        </td>
                      </tr>
                      <?php }?>     
                                            
                    </tbody>
                  </table>

                </div>
            </div><!-- end title -->
        
				
				
				
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end section -->













   

    <?php include ("footer.php")?>