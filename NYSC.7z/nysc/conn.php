
<?php

@session_start();
$host="localhost";
$db="nysc";
$pass="";
$user="root";

$conn = new mysqli($host, $user, $pass, $db) 
?>

