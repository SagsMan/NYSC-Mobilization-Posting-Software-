<?php include "header1.php"?>
<?php include "conn.php"?>
<?php 
                  $sql=$conn->query("select * from schools where usernames='".$_SESSION['USER']."'") or die($conn->error);
                  $ro=$sql->fetch_assoc();?>
<?php 
if(isset($_GET['del'])){

  $id=$_GET['del'];
 
$sql=$conn->query("DELETE FROM `students` where `id`='$id'") or die($conn->error);

echo '<script>alert("Data Deleted..");</script>';

echo '<script>window.location.href="mobilizationlist.php";</script>';

}
?>
	
	
    <div id="overviews" class="section lb">
        <div class="container">
            <div class="section-title row text-center">
                <div class="col-md-10 offset-md-1">
                    <h3>NATIONAL YOUTH SERVICE CORPS MOBILIZATION LIST</h3>
                    <h5><?php echo $ro['category'];?></h5>
          
                    <table class="table table-striped project-orders-table">
                    <thead>
                      <tr>
                        <th class="ml-5">SN</th>
                        <th>CALLUP</th>
                        <th>SURNAME</th>
                        <th>OTHER NAME(S)</th>
                        <th>SEX</th>
                        <th>DOB</th>
                        <th>STATE</th>
                        <th>SCHOOL NAME</th>
                        <th>COURSE</th>
                        <th>POSTING</th>
                        <th>CALLING</th>
                      
               
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php $i=1;
                      $sql=$conn->query("select * from students")  or die($conn->error);
                      while($row=$sql->fetch_assoc()){?>
                      <tr>
                        <td><?php echo $i++;?></td>
                    
                        <td><?php echo $row['surname'];?></td>
                        <td><?php echo $row['othername'];?></td>
                        <td><?php echo $row['sex'];?></td>
                        <td><?php echo $row['dob'];?></td>
                        <td><?php echo $row['state'];?></td>
                        <td><?php echo $row['schoolname'];?></td>
                        <td><?php echo $row['course'];?></td>
                        <td><?php echo $row['posting'];?></td>
                        
                   
                       
                       
                        
                        <td>
                          <div class="d-flex align-items-center">
                            <a type="button" class="btn btn-primary btn-sm btn-icon-text mr-3" href="studentview_detail.php?id=<?php echo $row['id'];?>">
                            <div class="btn.btn-dangerbtn-sm.btn-icon-text.r-3">View</div>
                              <i class="typcn typcn-edit btn-icon-append"></i>                          
                      </a>
                      <a type="button" class="btn btn-success btn-sm btn-icon-text mr-3" href="update.php?id=<?php echo $row['id'];?>">
                      <div class="btn.btn-dangerbtn-sm.btn-icon-text.r-3">Edit</div>
                              <i class="typcn typcn-edit btn-icon-append"></i>                          
                      </a>
                           <!-- <a type="button" class="btn btn-danger btn-sm btn-icon-text" href="mobilizationlist.php?del=<?php echo $row['id'];?>">
                              Delete
                              <i class="typcn typcn-delete-outline btn-icon-append"></i>                          
                      </a>-->
                          </div>
                        </td>
                      </tr>
                      <?php }?>     
                                            
                    </tbody>
                  </table>

                </div>
            </div><!-- end title -->				
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end section -->













   

    <?php include ("footer.php")?>