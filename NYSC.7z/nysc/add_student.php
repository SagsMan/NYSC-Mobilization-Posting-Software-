<?php include "header2.php"?>
<?php include("conn.php")?>


<?php 
if(isset($_POST['surname'])){

 $callup=$_POST['callup'];
  $surname=$_POST['surname'];
  $othername=$_POST['othername'];
  $sex=$_POST['sex'];
  $dob=$_POST['dob'];
  $state=$_POST['state'];
  $schoolname=$_POST['schoolname'];
  $course=$_POST['course'];
 $posting=$_POST['posting'];
  

$sql=$conn->query("INSERT INTO `students`( `surname`, `othername`,  `sex`, `dob`, `state`, `schoolname`, `course`) VALUES ('$surname','$othername', '$sex','$dob', '$state', '$schoolname', '$course')") or die($conn->error);
     //}
  }
?>
	
    <div id="overviews" class="section lb">
        <div class="container">
            <div class="section-title row text-center">
                <div class="col-md-10 offset-md-2">
                    <h3>Add Student</h3>
                    <form role="form" class="form-horizontal" method="POST">
							<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" name="callup" id="callup" placeholder="Callup" type="text">
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" name="surname" id="surname" placeholder="Surname" type="text">
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" name="othername" id="othername" placeholder="Othername" type="text">
								</div>
                                </div>
                                <div class="form-group">
                                    
								<div class="col-sm-12">
									<input class="form-control" name="sex" id="sex" placeholder="Sex" type="text">
								</div>
                                </div>
								<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" name="dob" id="dob" placeholder="Dob" type="date">
								</div>
							</div>
                                <div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" name="state" id="state" placeholder="State" type="text">
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" name="schoolname" id="schoolname" placeholder="School Name" type="text">
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" name="course" id="course" placeholder="Course" type="text">
								</div>
							</div>
                          <div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" name="posting" id="posting" placeholder="Posting" type="text">
								</div>
							</div>
							<div class="row">							
								<div class="col-sm-10">
									<button type="submit" class="btn btn-light btn-radius btn-brd grd1">
										Save &amp; Continue
									</button>
									<button type="reset" class="btn btn-light btn-radius btn-brd grd1">
										Cancel</button>
								</div>
							</div>
						</form>

                </div>
            </div><!-- end title -->
        
				
				
				
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end section -->













   

    <?php include "footer.php"?>