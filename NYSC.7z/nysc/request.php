<?php include "header1.php"?>
<?php include "conn.php"?>
	
	
    <div id="overviews" class="section lb">
        <div class="container">
            <div class="section-title row text-center">
                <div class="col-md-10 offset-md-2">
                    <h3>School List</h3>
                    <table class="table table-striped project-orders-table">
                    <thead>
                      <tr>
                        <th class="ml-5">SN</th>
                       
                        <th>CODE</th>
                        <th>SCHOOL NAME(S)</th>
                        <th>DATE RECIVED</th>
               
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php $i=1;
                      $sql=$conn->query("select * from schools")  or die($conn->error);
                      while($row=$sql->fetch_assoc()){?>
                      <tr>
                        <td><?php echo $i++;?></td>
                        <td><?php echo $row['assigncode'];?> </td>
                        <td><?php echo $row['category'];?></td>
                        <td><?php echo $row['updated_at'];?></td>
                       
                        
                        <td>
                          <div class="d-flex align-items-center">
                            <a type="button" class="btn btn-success btn-sm btn-icon-text mr-3" href="result_view.php?edit=16">
                              View
                              <i class="typcn typcn-edit btn-icon-append"></i>                          
                      </a>
                           
                          </div>
                        </td>
                      </tr>
                                 
                      <?php }?>                
                    </tbody>
                  </table>

                </div>
            </div><!-- end title -->
        
				
				
				
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end section -->













   

    <?php include "footer.php"?>