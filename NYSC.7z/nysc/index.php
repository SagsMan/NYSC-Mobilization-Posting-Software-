<?php include "header.php"?>

    <div id="overviews" class="section lb">
        <div class="container">    
            <div class="row align-items-center">
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    <div class="message-box">
                        <h2>WELCOME TO THE NYSC POSTING SYSTEM</h2>
                        <h4>ABOUT THE SCHEME</h4>
                        <p>The NYSC scheme was created in a bid to reconstruct, reconcile and rebuild the country after the Nigerian Civil war. The unfortunate antecedents in our national history gave impetus to the establishment of the National Youth Service Corps by decree No.24 of 22nd May 1973 which stated that the NYSC is being established "with a view to the proper encouragement and development of common ties among the youths of Nigeria and the promotion of national unity". As a developing country. Nigeria is further plagued by the problems attendant upon a condition of under development, namely; poverty. mass illiteracy, acute shortage of high skilled manpower (coupled with most uneven distribution of the skilled people that are available), woefully inadequate socioeconomic infrastructural facilities, housing.</p>


                    </div><!-- end messagebox -->
                </div><!-- end col -->
				
				<div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    <div class="post-media wow fadeIn">
                        <img src="img/nysc.jpg" alt="" class="img-fluid img-rounded">
                    </div><!-- end media -->
                </div><!-- end col -->
			</div>
			<div class="row align-items-center">
				<div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    <div class="post-media wow fadeIn">
                        <img src="img/nysc3.jfif" alt="" class="img-fluid img-rounded">
                    </div><!-- end media -->
                </div><!-- end col -->
				
				<div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    <div class="message-box">
                        <h2>Vision Statement</h2>
                        <p>To develop a sound and result oriented organization that is strongly committed to its set objectives particularly those of national unity and even development. An organization that is well motivated and capable of bringing out the best qualities in our youths and imparting in them the right attitude and values for nation-building. An organization that serves as a catalyst to national development, and a source of pride and fulfillment to its participating graduate youths</p>


                       
                    </div><!-- end messagebox -->
                </div><!-- end col -->
				
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end section -->


































   
  <?php include "footer.php"?>