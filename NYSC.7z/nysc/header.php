<?php include ("conn.php")?>
<?php 
if(isset($_POST['username'])){
    
	$username=$_POST['username'];
	$password=$_POST['password'];
	$sql= $conn->query("select * from users where username ='$username' and password='$password'") or die($conn->error);
	$row= $sql->fetch_assoc();
	$cnt = $sql->num_rows;
	
	if($cnt>0){
	  $_SESSION['USER'] = $username;
	  $_SESSION['NAMES'] = $password; 
	  header("location:dashboard.php");
	  $_SESSION['LEVEL'] ='users';
	
	  echo '<script>window.location.href="mobilizationlist.php";</script>';
	  
	  
	  }else{
		  echo '<script><h5>Oops! Invalid Username and Password </h5></script>';
	
	
	
	
	
	
	
	}
	   // echo '<h5>Oops! Invalid Email and Password </h5>';
	
	}
	
	?>
	
<!DOCTYPE html>
<html lang="en">

    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
   
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
     <!-- Site Metas -->
    <title>NYSC</title>  
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- ALL VERSION CSS -->
    <link rel="stylesheet" href="css/versions.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!-- Modernizer for Portfolio -->
    <script src="js/modernizer.js"></script>

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body class="host_version"> 

	<!-- Modal -->
	<div class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header tit-up">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Login</h4>
			</div>
			<div class="modal-body customer-box">
				<!-- Nav tabs -->
				<ul class="nav nav-tabs">
					<li><a class="active" href="#Login" data-toggle="tab">Admin</a></li>
					<li><a href="#Signin" data-toggle="tab">School</a></li>
				</ul>
				<!-- Tab panes -->
				<div class="tab-content">
					<div class="tab-pane active" id="Login">
						<form role="form" class="form-horizontal"  method="post">
							<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" id="username" name="username" placeholder="Username" type="text">
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" id="Password1" name="password" placeholder="Password" type="password">
								</div>
							</div>
							<div class="row">
								<div class="col-sm-10">
									<button type="submit" class="btn btn-light btn-radius btn-brd grd1">
										Submit
									</button>
								</div>
							</div>
						</form>
					</div>
					<?php 
if(isset($_POST['usernames'])){
    
	$usernames=$_POST['usernames'];
	$password=$_POST['password'];
	$sql= $conn->query("select * from schools where usernames='$usernames' and password='$password'") or die($conn->error);
	$row= $sql->fetch_assoc();
	$cnt = $sql->num_rows;
	
	if($cnt>0){
	  $_SESSION['USER'] = $usernames;
	  $_SESSION['NAMES'] = $password; 
	  //header("location:dashboard.php");
	  $_SESSION['LEVEL'] ='schools';
	
	  echo '<script>window.location.href="mobilizationlist2.php";</script>';
	  
	  
	  }else{
		  echo '<h5>Oops! Invalid Name and Password </h5>';
	
	
	
	
	
	
	
	}
	   // echo '<h5>Oops! Invalid Email and Password </h5>';
	
	}
	
	?>
					<div class="tab-pane" id="Signin">
					<form role="form" class="form-horizontal"  method="post">
							<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" id="usernames" name="usernames" placeholder="Usernames" type="text">
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-12">
									<input class="form-control" id="password"  name="password" placeholder="Password" type="password">
								</div>
							</div>
							<div class="row">
								<div class="col-sm-10">
									<button type="submit" class="btn btn-light btn-radius btn-brd grd1">
										Submit
									</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	  </div>
	</div>

    <!-- LOADER -->
	<div id="preloader">
		<div class="loader-container">
			<div class="progress-br float shadow">
				<div class="progress__item"></div>
			</div>
		</div>
	</div>
	<!-- END LOADER -->	
	
	<!-- Start header -->
	<header class="top-navbar">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
			<div class="container-fluid">
				<a class="navbar-brand" href="index.php">
					<img src="images/nysc1.jfif" alt="" />
					<h2 style="color: white;">NYSC Posting System</h2>
				</a>
				
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbars-host" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
					<span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbars-host">
					<ul class="navbar-nav ml-auto">
						<li class="nav-item active"><a class="nav-link" href="index.php"></a></li>
						<li class="nav-item"></li>
						<li class="nav-item"></li>
                        <li class="nav-item"></li>
						<li class="nav-item"></li>
						<li class="nav-item"></li>
					</ul>
					<ul class="nav navbar-nav navbar-right">
					<!--<form class="form-inline">
                        <div class="checkdomain-wrapper">
                            <div class="form-group">
                                <label class="sr-only" for="domainnamehere">Domain name</label>
                                <input type="text" class="form-control" id="domainnamehere" placeholder="Enter domain name here..">
                                <button type="submit" class="btn btn-primary grd1"><i class="fa fa-search"></i></button>
                            </div>
                           </div>
                    </form>-->
                        <li><a class="hover-btn-new log" href="#" data-toggle="modal" data-target="#login"><span>Admin | School</span></a></li>
                    </ul>
				</div>
			</div>
		</nav>
	</header>
	<!-- End header -->